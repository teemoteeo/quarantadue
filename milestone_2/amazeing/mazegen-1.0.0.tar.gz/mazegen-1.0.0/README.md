*42 Firenze — tcostant, acentron*

# A-MAZE-ING

```
 █████╗  ███╗   ███╗ █████╗ ███████╗███████╗ ██╗███╗   ██╗ ██████╗
██╔══██╗ ████╗ ████║██╔══██╗╚══███╔╝██╔════╝ ██║████╗  ██║██╔════╝
███████║ ██╔████╔██║███████║  ███╔╝ █████╗   ██║██╔██╗ ██║██║  ███╗
██╔══██║ ██║╚██╔╝██║██╔══██║ ███╔╝  ██╔══╝   ██║██║╚██╗██║██║   ██║
██║  ██║ ██║ ╚═╝ ██║██║  ██║███████╗███████╗ ██║██║ ╚████║╚██████╔╝
╚═╝  ╚═╝ ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝
```

Maze generator and terminal visualizer. Reads a config file, generates
a maze with recursive backtracking (DFS), solves it with bidirectional
BFS, and renders it in the terminal via `curses`.

---

## Usage

```bash
make install              # install dependencies
make run                  # run with config.txt
python3 a_maze_ing.py my_config.txt
make lint && make test
```

## Config File (`KEY=VALUE`, `#` = comment)

| Key | Description |
|-----|-------------|
| `WIDTH` / `HEIGHT` | Maze size in cells |
| `ENTRY` / `EXIT` | Coordinates as `x,y` |
| `OUTPUT_FILE` | Output filename |
| `PERFECT` | `TRUE` = single path between all cells |
| `SEED` | Optional RNG seed for reproducibility |

## Visualizer Controls

| Key | Action |
|-----|--------|
| `R` | Regenerate |
| `P` | Toggle shortest path (animated BFS) |
| `C` | Cycle wall colors |
| `Q` / `ESC` | Quit |

---

## Output File Format

```
<WIDTH hex digits> × HEIGHT rows

<entry_x>,<entry_y>
<exit_x>,<exit_y>
<path as N/E/S/W letters>
```

---

## Cell Encoding

One hex digit per cell. Each bit = one wall (1 = closed):

| Bit | Wall | Value |
|-----|------|-------|
| 0 (LSB) | North | 1 |
| 1 | East | 2 |
| 2 | South | 4 |
| 3 | West | 8 |

`0xF` = all walls closed. `0x6` = East + South closed.

---

## Algorithm

**Generation:** DFS from entry. Carves passages by clearing wall bits
in both current and neighbour cell. Backtracks when stuck. Guarantees
a perfect maze (unique path between any two cells).

**Solving:** Bidirectional BFS — two frontiers expand from entry and
exit simultaneously, meet in the middle. Path reconstructed from both
visited dictionaries.

**"42" pattern:** A region of fully closed cells (`0xF`) forming the
digits "42" is embedded before DFS runs, so the carver never touches
those cells. Requires maze ≥ 11×11.

---

## mazegen Package

```bash
pip install mazegen-1.0.0-py3-none-any.whl
```

```python
from mazegen import MazeGenerator
maze = MazeGenerator(width=20, height=15,
                     entry=(0, 0), exit=(19, 14), seed=42)
print(maze.grid)      # list[list[int]]
print(maze.solution)  # "NNEESS..."
```

Build: `python3 -m build` → `dist/mazegen-1.0.0-py3-none-any.whl`

---

## Project Structure

```
a_maze_ing.py   # entry point
generator.py    # MazeGenerator (DFS + 42 pattern + BFS output)
parser.py       # config parser and MazeConfig
visualizer.py   # curses visualizer + bidirectional BFS
mazegen.py      # standalone pip package
config.txt      # default config
```

---

## Team

| Member | Responsibilities |
|--------|-----------------|
| tcostant | <!-- TODO --> |
| acentron | <!-- TODO --> |

**Planning:**
<!-- TODO: initial plan, how it evolved, what worked, what didn't, tools used -->

---

## AI Usage

<!-- TODO: which parts were assisted by AI and how -->

All AI-generated content was reviewed, understood, and validated.

---

## References

- [Maze generation — Wikipedia](https://en.wikipedia.org/wiki/Maze_generation_algorithm)
- [Recursive backtracker — jamisbuck.org](http://weblog.jamisbuck.org/2010/12/27/maze-generation-recursive-backtracker)
- [BFS — cp-algorithms.com](https://cp-algorithms.com/graph/bfs.html)
- [curses — docs.python.org](https://docs.python.org/3/library/curses.html)
- [Packaging — packaging.python.org](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
